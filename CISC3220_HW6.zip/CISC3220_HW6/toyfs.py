import os
import struct
import threading

BLOCK_SIZE = 256
TOTAL_BLOCKS = 256
TOTAL_INODES = 64
DATA_START = 19
INODE_SIZE = 64
ENTRY_SIZE = 32
MAX_FILE_SIZE = 74 * BLOCK_SIZE


class FSError(Exception):
    pass


class ToyFS:
    def __init__(self, image_path="disk.img"):
        self.image_path = image_path
        self.lock = threading.RLock()
        if image_path and os.path.exists(image_path):
            self.load(image_path)
        else:
            self.mkfs()

    def _offset(self, block):
        return block * BLOCK_SIZE

    def _bit(self, bitmap_block, number):
        pos = self._offset(bitmap_block) + number // 8
        return (self.disk[pos] >> (number % 8)) & 1

    def _set_bit(self, bitmap_block, number, used):
        pos = self._offset(bitmap_block) + number // 8
        mask = 1 << (number % 8)
        if used:
            self.disk[pos] |= mask
        else:
            self.disk[pos] &= ~mask

    def _inode(self, number):
        pos = self._offset(3) + number * INODE_SIZE
        values = struct.unpack_from("<BI10II", self.disk, pos)
        return {"type": values[0], "size": values[1],
                "direct": list(values[2:12]), "indirect": values[12]}

    def _put_inode(self, number, inode):
        pos = self._offset(3) + number * INODE_SIZE
        values = [inode["type"], inode["size"]] + inode["direct"] + [inode["indirect"]]
        struct.pack_into("<BI10II", self.disk, pos, *values)
        self.disk[pos + 49:pos + INODE_SIZE] = bytes(15)

    def _empty_inode(self, kind):
        return {"type": kind, "size": 0, "direct": [0] * 10, "indirect": 0}

    def _blocks(self, inode):
        count = (inode["size"] + BLOCK_SIZE - 1) // BLOCK_SIZE
        result = [b for b in inode["direct"] if b != 0]
        if inode["indirect"]:
            for i in range(64):
                b = struct.unpack_from("<I", self.disk,
                                       self._offset(inode["indirect"]) + i * 4)[0]
                if b:
                    result.append(b)
        return result[:count]

    def _all_blocks(self, inode):
        result = self._blocks(inode)
        if inode["indirect"]:
            result.append(inode["indirect"])
        return result

    def _free_inodes(self):
        return [i for i in range(TOTAL_INODES) if not self._bit(1, i)]

    def _free_blocks(self):
        return [i for i in range(DATA_START, TOTAL_BLOCKS) if not self._bit(2, i)]

    def _allocate(self, inode, data, chosen):
        # Chosen blocks are reserved by the caller after validation.
        count = (len(data) + BLOCK_SIZE - 1) // BLOCK_SIZE
        inode["size"] = len(data)
        inode["direct"] = [0] * 10
        inode["indirect"] = 0
        for i in range(count):
            block = chosen[i]
            self._set_bit(2, block, True)
            start = self._offset(block)
            self.disk[start:start + BLOCK_SIZE] = data[i * BLOCK_SIZE:(i + 1) * BLOCK_SIZE].ljust(BLOCK_SIZE, b"\x00")
            if i < 10:
                inode["direct"][i] = block
        if count > 10:
            pointer = chosen[count]
            self._set_bit(2, pointer, True)
            inode["indirect"] = pointer
            start = self._offset(pointer)
            self.disk[start:start + BLOCK_SIZE] = bytes(BLOCK_SIZE)
            for i in range(10, count):
                struct.pack_into("<I", self.disk, start + (i - 10) * 4, chosen[i])

    def _release(self, inode):
        for block in self._all_blocks(inode):
            self._set_bit(2, block, False)
            start = self._offset(block)
            self.disk[start:start + BLOCK_SIZE] = bytes(BLOCK_SIZE)

    def _parts(self, path):
        if not isinstance(path, str) or not path.startswith("/"):
            raise FSError("absolute path required")
        parts = [p for p in path.split("/") if p]
        for part in parts:
            if part in (".", ".."):
                raise FSError("relative components not supported")
            if len(part.encode("utf-8")) > 28 or "\x00" in part:
                raise FSError("invalid or too long name")
        return parts

    def _entries(self, inode):
        entries = []
        for block in self._blocks(inode):
            for slot in range(8):
                pos = self._offset(block) + slot * ENTRY_SIZE
                raw = bytes(self.disk[pos:pos + 28])
                if raw[0] != 0:
                    name = raw.split(b"\x00", 1)[0].decode("utf-8")
                    number = struct.unpack_from("<I", self.disk, pos + 28)[0]
                    entries.append((name, number, pos))
        return entries

    def _lookup(self, directory, name):
        for entry_name, number, pos in self._entries(self._inode(directory)):
            if entry_name == name:
                return number, pos
        return None, None

    def _resolve(self, path):
        current = 0
        for name in self._parts(path):
            inode = self._inode(current)
            if inode["type"] != 2:
                raise FSError("not a directory")
            number, _ = self._lookup(current, name)
            if number is None:
                raise FSError("not found")
            current = number
        return current

    def _parent(self, path):
        parts = self._parts(path)
        if not parts:
            raise FSError("cannot modify root")
        parent = self._resolve("/" + "/".join(parts[:-1]))
        if self._inode(parent)["type"] != 2:
            raise FSError("not a directory")
        return parent, parts[-1]

    def _entry_space(self, parent):
        inode = self._inode(parent)
        for block in self._blocks(inode):
            for slot in range(8):
                pos = self._offset(block) + slot * ENTRY_SIZE
                if self.disk[pos] == 0:
                    return pos, False
        if len(self._blocks(inode)) >= 74:
            raise FSError("directory full")
        return None, True

    def _add_entry(self, parent, name, number, slot, grow_block):
        inode = self._inode(parent)
        if grow_block is not None:
            old = self._read_data(inode)
            chosen = self._all_blocks(inode) + [grow_block]
            # If growth crosses the direct-pointer limit, reserve an extra pointer block.
            if (len(old) // BLOCK_SIZE) >= 10 and not inode["indirect"]:
                raise FSError("directory growth needs indirect pointer")
            # Extend the existing inode without reallocating previous blocks.
            old_count = len(self._blocks(inode))
            self._set_bit(2, grow_block, True)
            self.disk[self._offset(grow_block):self._offset(grow_block) + BLOCK_SIZE] = bytes(BLOCK_SIZE)
            if old_count < 10:
                inode["direct"][old_count] = grow_block
            else:
                struct.pack_into("<I", self.disk,
                                 self._offset(inode["indirect"]) + (old_count - 10) * 4,
                                 grow_block)
            inode["size"] += BLOCK_SIZE
            self._put_inode(parent, inode)
            slot = self._offset(grow_block)
        name_bytes = name.encode("utf-8")
        self.disk[slot:slot + 28] = name_bytes.ljust(28, b"\x00")
        struct.pack_into("<I", self.disk, slot + 28, number)

    def _read_data(self, inode):
        result = bytearray()
        for block in self._blocks(inode):
            result.extend(self.disk[self._offset(block):self._offset(block) + BLOCK_SIZE])
        return bytes(result[:inode["size"]])

    def mkfs(self):
        with self.lock:
            self.disk = bytearray(BLOCK_SIZE * TOTAL_BLOCKS)
            struct.pack_into("<4sIIIIII", self.disk, 0, b"TFS1", BLOCK_SIZE,
                             TOTAL_BLOCKS, TOTAL_INODES, 1, 2, DATA_START)
            for block in range(DATA_START):
                self._set_bit(2, block, True)
            self._set_bit(1, 0, True)
            root = self._empty_inode(2)
            root["size"] = BLOCK_SIZE
            root["direct"][0] = DATA_START
            self._set_bit(2, DATA_START, True)
            self._put_inode(0, root)

    def mkdir(self, path):
        with self.lock:
            parent, name = self._parent(path)
            if self._lookup(parent, name)[0] is not None:
                raise FSError("exists")
            free_inodes = self._free_inodes()
            slot, grow = self._entry_space(parent)
            free = self._free_blocks()
            needed = 1 + int(grow)
            if not free_inodes:
                raise FSError("no free inodes")
            if len(free) < needed:
                raise FSError("disk full")
            if grow and len(self._blocks(self._inode(parent))) >= 10 and not self._inode(parent)["indirect"]:
                raise FSError("directory growth needs indirect pointer")
            number = free_inodes[0]
            self._set_bit(1, number, True)
            inode = self._empty_inode(2)
            inode["size"] = BLOCK_SIZE
            inode["direct"][0] = free[0]
            self._set_bit(2, free[0], True)
            self._put_inode(number, inode)
            self._add_entry(parent, name, number, slot, free[1] if grow else None)

    def write(self, path, data):
        with self.lock:
            if isinstance(data, str):
                data = data.encode("utf-8")
            if not isinstance(data, bytes):
                raise FSError("write expects bytes")
            if len(data) > MAX_FILE_SIZE:
                raise FSError("file too large")
            parent, name = self._parent(path)
            number, _ = self._lookup(parent, name)
            new = number is None
            if not new and self._inode(number)["type"] != 1:
                raise FSError("not a file")
            slot, grow = self._entry_space(parent) if new else (None, False)
            if new and not self._free_inodes():
                raise FSError("no free inodes")
            old_inode = self._inode(number) if not new else None
            old_blocks = self._all_blocks(old_inode) if old_inode else []
            count = (len(data) + BLOCK_SIZE - 1) // BLOCK_SIZE
            required = count + int(count > 10)
            if grow and len(self._blocks(self._inode(parent))) >= 10 and not self._inode(parent)["indirect"]:
                raise FSError("directory growth needs indirect pointer")
            free = sorted(self._free_blocks() + old_blocks)
            if len(free) < required + int(grow):
                raise FSError("disk full")
            if new:
                number = self._free_inodes()[0]
                self._set_bit(1, number, True)
            else:
                self._release(old_inode)
            inode = self._empty_inode(1)
            self._allocate(inode, data, free[:required])
            self._put_inode(number, inode)
            if new:
                self._add_entry(parent, name, number, slot,
                                free[required] if grow else None)

    def read(self, path):
        with self.lock:
            inode = self._inode(self._resolve(path))
            if inode["type"] != 1:
                raise FSError("not a file")
            return self._read_data(inode)

    def cat(self, path):
        return self.read(path)

    def ls(self, path="/"):
        with self.lock:
            inode = self._inode(self._resolve(path))
            if inode["type"] != 2:
                raise FSError("not a directory")
            result = []
            for name, number, _ in self._entries(inode):
                child = self._inode(number)
                result.append((name + ("/" if child["type"] == 2 else ""), child["size"] if child["type"] == 1 else 0))
            return result

    def rm(self, path):
        with self.lock:
            parent, name = self._parent(path)
            number, pos = self._lookup(parent, name)
            if number is None:
                raise FSError("not found")
            inode = self._inode(number)
            if inode["type"] == 2 and self._entries(inode):
                raise FSError("directory not empty")
            self._release(inode)
            self._set_bit(1, number, False)
            self._put_inode(number, self._empty_inode(0))
            self.disk[pos:pos + ENTRY_SIZE] = bytes(ENTRY_SIZE)

    def stat(self, path):
        with self.lock:
            number = self._resolve(path)
            inode = self._inode(number)
            return {"inode": number, "type": "directory" if inode["type"] == 2 else "file",
                    "size": inode["size"] if inode["type"] == 1 else 0,
                    "blocks": self._blocks(inode), "indirect": inode["indirect"]}

    def fsstat(self):
        with self.lock:
            files = dirs = used_inodes = 0
            for i in range(TOTAL_INODES):
                if self._bit(1, i):
                    used_inodes += 1
                    if self._inode(i)["type"] == 1:
                        files += 1
                    else:
                        dirs += 1
            used_data = sum(self._bit(2, i) for i in range(DATA_START, TOTAL_BLOCKS))
            return {"inodes_used": used_inodes, "inodes_free": TOTAL_INODES - used_inodes,
                    "data_blocks_used": used_data, "data_blocks_free": TOTAL_BLOCKS - DATA_START - used_data,
                    "files": files, "directories": dirs}

    def check(self):
        with self.lock:
            reachable = set()
            seen_inodes = set()
            def walk(number):
                if number in seen_inodes:
                    raise FSError("inode referenced twice")
                seen_inodes.add(number)
                if not self._bit(1, number):
                    raise FSError("directory references free inode")
                inode = self._inode(number)
                for block in self._all_blocks(inode):
                    if block < DATA_START or block >= TOTAL_BLOCKS or block in reachable:
                        raise FSError("invalid or duplicate data block")
                    reachable.add(block)
                if inode["type"] == 2:
                    for _, child, _ in self._entries(inode):
                        walk(child)
            walk(0)
            allocated = {i for i in range(DATA_START, TOTAL_BLOCKS) if self._bit(2, i)}
            if reachable != allocated:
                raise FSError("data bitmap does not match inodes")
            inode_set = {i for i in range(TOTAL_INODES) if self._bit(1, i)}
            if inode_set != seen_inodes:
                raise FSError("inode bitmap does not match directories")
            return True

    def save(self, image_path=None):
        with self.lock:
            path = image_path or self.image_path
            if not path:
                raise FSError("image path required")
            with open(path, "wb") as file:
                file.write(self.disk)

    def load(self, image_path=None):
        with self.lock:
            path = image_path or self.image_path
            with open(path, "rb") as file:
                disk = bytearray(file.read())
            if len(disk) != BLOCK_SIZE * TOTAL_BLOCKS:
                raise FSError("invalid disk image size")
            magic, block_size, blocks, inodes, ib, bb, start = struct.unpack_from("<4sIIIIII", disk, 0)
            if (magic, block_size, blocks, inodes, ib, bb, start) != (b"TFS1", 256, 256, 64, 1, 2, 19):
                raise FSError("invalid disk image format")
            old = getattr(self, "disk", None)
            self.disk = disk
            try:
                self.check()
            except Exception:
                self.disk = old
                raise


# This command loop is only used when toyfs.py is run directly.
# Importing ToyFS into another program does not start the shell.
def main():
    import shlex
    fs = ToyFS()
    print("CISC 3320 HW6 Toy File System. Type help for commands.")
    while True:
        try:
            line = input("toyfs> ").strip()
            if not line:
                continue
            parts = shlex.split(line)
            cmd = parts[0].lower()
            if cmd == "help":
                print("mkdir PATH | ls [PATH] | write PATH TEXT | cat PATH | rm PATH")
                print("stat PATH | fsstat | check | save | exit")
            elif cmd == "mkdir":
                fs.mkdir(parts[1])
                print("Directory created")
            elif cmd == "ls":
                for name, size in fs.ls(parts[1] if len(parts) > 1 else "/"):
                    print(name, size)
            elif cmd == "write":
                fs.write(parts[1], " ".join(parts[2:]).encode("utf-8"))
                print("File written")
            elif cmd == "cat":
                print(fs.cat(parts[1]).decode("utf-8"))
            elif cmd == "rm":
                fs.rm(parts[1])
                print("Removed")
            elif cmd == "stat":
                print(fs.stat(parts[1]))
            elif cmd == "fsstat":
                print(fs.fsstat())
            elif cmd == "check":
                print("Consistency:", "OK" if fs.check() else "FAILED")
            elif cmd == "save":
                fs.save()
                print("Saved")
            elif cmd == "exit":
                fs.save()
                print("Saved. Goodbye!")
                break
            else:
                print("Unknown command")
        except (FSError, IndexError, ValueError, UnicodeError) as error:
            print("Error:", error)
        except (KeyboardInterrupt, EOFError):
            fs.save()
            print("\nSaved. Goodbye!")
            break


if __name__ == "__main__":
    main()
