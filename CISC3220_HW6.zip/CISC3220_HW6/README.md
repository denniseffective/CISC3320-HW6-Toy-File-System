# CISC 3320 — Homework 6: Toy File System

**Student:** Dennis Rostov  
**Course:** CISC 3320 — Operating Systems

## Description

This project implements a simulated file system in Python using a fixed-size disk image.

The file system includes a superblock, inode and data block bitmaps, an inode table, directories, direct and indirect block pointers, and persistent disk storage.

## Features

- Create and list directories
- Create and write files
- Read file contents
- Remove files and directories
- Display file metadata
- Display file system statistics
- Check file system consistency
- Save and load a persistent disk image

## Requirements

- Python 3
- No external packages required

## How to Run

Open a terminal in the project folder and enter:

```bash
python toyfs.py
```

## Example Commands

```text
mkdir /documents
write /documents/notes.txt Hello
cat /documents/notes.txt
ls /documents
stat /documents/notes.txt
fsstat
check
exit
```

## Testing

The file system can be tested through the command-line interface by creating, reading, and deleting files and directories, checking allocation statistics, and restarting the program to verify persistence.

The consistency checker can be run using:

```text
check
```

## Files

- `toyfs.py` — File system implementation and command-line interface
- `disk.img` — Generated persistent disk image (created automatically when the program runs)